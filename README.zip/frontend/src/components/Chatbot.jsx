// Chatbot component
